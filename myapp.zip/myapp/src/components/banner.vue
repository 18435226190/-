<template>
  <div class="hello">
    <div >
    <h1>
      <input type="text" placeholder="montain">
      <img src="../../static/images/search.png" alt="">
    </h1>
    <h2>
      <img src="../../static/images/banner.jpg" alt="">
    </h2>
  </div>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .hello{width: 100%}
  h1{background-image: url("../../static/images/background.jpg");text-align: center;position: relative}
  h1 input{background: #fecad7;height:0.3rem;width:80%;margin-top: 0.3rem;border-radius: 0.1rem;padding-left: 0.13rem}
  h1 img{width: 3%;position: absolute;top: 0.4rem;right: 10%;}
  h2 img{max-width: 7.50rem;z-index: -1;width: 100%}


</style>
