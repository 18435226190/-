<template>
  <div class="me">
     <div style="background: #f90">
       <img src="../../static/images/phone.jpg" alt="" width="100%" >
       <div style="padding: 0.2rem;text-align: center;height:1.2rem;position: relative">
       <img src="../../static/images/more/set1.png" alt="" class="fl" width="8%">
         <span style="color:#fff">个人中心</span>
       <img src="../../static/images/more/news.png" alt="" class="fr" width="8%">
         <img src="../../static/images/more/man.png" alt="" style="position: absolute;bottom: -32%;left: 37.5%" width="25%" @click="login()" v-show="!tag">
         <img src="../../static/images/more/man.jpg" alt="" style="position: absolute;bottom: -32%;left: 37.5%;border-radius: 50%" width="25%" v-show="tag">
       </div>
     </div>
    <p style="padding: 0.8rem 0 0;text-align: center" v-show="!tag"><span @click="login()">点击登录</span></p>
    <p style="padding: 0.8rem 0 0;text-align: center" v-show="tag"><span>{{name}}</span></p>
    <p style="padding:0.1rem;border-bottom: 0.04rem solid #eee"><img src="../../static/images/more/keep.png" alt="" width="5%"><span style="margin-left: 0.2rem">我的收藏</span><span v-show="tag">(5)</span></p>
    <p style="padding:0.2rem;border-bottom: 0.01rem solid #ddd;overflow: hidden"><span class="fl" >我的订单</span> <span class="fr" style="color:#999">查看全部订单</span></p>
    <ul class="order">
      <li>
        <img src="../../static/images/more/boli.png" alt=""><br><br>待付款
      </li>
      <li style="position: relative">
        <img src="../../static/images/more/pre.png" alt=""><br><br>待发货
        <span style="position: absolute;right:0;top:0;width: 70%" v-show="tag"><img src="../../static/images/more/red1.jpg" alt="" ></span>
      </li>
      <li style="position: relative">
        <img src="../../static/images/more/cons.png" alt=""><br><br>待收货
        <span style="position: absolute;right:0;top:0;width: 70%" v-show="tag"><img src="../../static/images/more/red2.jpg" alt=""></span>
      </li>
      <li>
        <img src="../../static/images/more/eva.png" alt=""><br><br>待评价
      </li>
      <li>
        <img src="../../static/images/more/refu.png" alt=""><br><br>退款/售后
      </li>
    </ul>
    <div style="padding: 0.2rem;color:#999" >
      收货地址管理
    </div>
  </div>
</template>
<script>
  export default{
      data(){
          return {
              tag:false,
              name:''
          }
      },
      methods:{
          login(){
              this.$router.push({
                path:'./login'
              })
          }
      },
    mounted(){
      this.tag=JSON.parse(sessionStorage.getItem(sessionStorage.key(0))).tag;
      this.name=JSON.parse(sessionStorage.getItem(sessionStorage.key(0))).name;
    }
  }



</script>
<style scoped>
  .me{padding-bottom: 1rem}
  .me .order {display: flex;text-align: center;padding: 0.2rem 0;border-bottom: 0.1rem solid #eee}
  .me .order li{text-align: center;flex: 1;font-size: 0.15rem}
  .me .order li img{width: 28%}
</style>
