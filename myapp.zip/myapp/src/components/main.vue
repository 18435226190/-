<template>
  <div>
  <banner></banner>
  <div class="main">
    <div v-for="(item,index) in data" :key="index">
      <div class="name">
        <img :src="icoImg[index]" alt="" width="7%" >
        <span class="title">{{item.name}}</span>
      </div>
      <ul v-if="index===0">
        <li v-for="(val,i) in item['list']" @click="on(val.id)">
          <img :src="val.thumbnail" alt="">
          <p>
            <i>￥{{val.reduct_price}}</i><em class="fr" style="text-decoration: line-through">￥{{val.original_price}}</em>
          </p>
          <p><span>{{val.name}}</span></p>
        </li>
      </ul>
      <ul v-else>
      <li  v-for="(val) in item['list']" @click="on(val.id)">
      <img :src="val.thumbnail" alt="">
      <p><span>{{val.name}}</span></p>
      <p>
      <i style="color: #ff9f02">￥{{val.reduct_price}}</i><em class="fr">￥{{val.original_price}}</em>
      </p>
      </li>
      </ul>
    </div>
  </div>
  </div>
</template>
<script>
  import banner from './banner.vue'
  export default {
      methods:{
          on(id){
              console.log(id);
              this.$router.push({
                path:'./detail?id='+id
              })
          }
      },
    data(){
      return {
        data: [],
        icoImg: ['../../static/images/today-ico.jpg', '../../static/images/baby.jpg', '../../static/images/beaty.jpg', '../../static/images/house.jpg','../../static/images/food.jpg', '../../static/images/fly.jpg']
      }
    },
    mounted(){
      this.$http({
        url: 'http://yd.msword.top/getIndexData'
      }).then((res) => {
        this.data = res.data.data;
        console.log(res.data.data[0].list)
      });
      console.log(this.$router.currentRoute.path);
      this.$store.dispatch('add2',this.$router.currentRoute.path);

    },
    components:{
        banner
    }
  }
</script>
<style scoped>
  .main {
    padding: 0 0 1rem 0.23rem;
  }

  .name {
    padding: .3rem 0
  }

  .title {
    margin: 0.07rem 0 0 0.21rem;
  }

  ul {
    display: flex;
    white-space: nowrap;
  }

  ul li {
    width: 60%;
    margin-right: 0.23rem;
    border: 0.01rem solid #efefef;
    display: inline-block;
  }

  ul li img {
    width: 100%
  }

  ul li p {
    padding: 0.09rem 0.1rem 0.09rem 0.1rem;
    white-space: normal
  }
  ul li p span{
    height: 0.46rem;
  }

</style>
