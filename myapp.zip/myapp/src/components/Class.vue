<template>
  <div class="class">
    <div class="banner">
      <img src="../../static/images/phone.jpg" alt="" class="ban">
      <div><input type="text" placeholder="Mountain">
      <img src="../../static/images/search.png" alt="" class="search"></div>
    </div>
    <div class="body">
      <el-tabs :tab-position="tabPosition">
        <el-tab-pane :label="item.name" style="height:0.93rem"  v-for="(item,index) in dataList" :key="index">
          <ul >
            <li class="fl" v-for="(val,i) in item.list" :key="i">
              <img :src="val.thumbnail" alt="">
              <p>{{val.name}}</p>
            </li>
          </ul>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
  export default{
      name:'Class',
    data() {
      return {
        tabPosition: 'left',
        dataList:[]
      };
    },
    methods:{
      on(id){
        console.log(id);
        this.$router.push({
          path:'./detail?id='+id
        })
      }
    },
    mounted(){
          this.$http({
            url:'http://yd.msword.top/getClassify'
          }).then((res)=>{
            console.log(res.data.data[0]);
            this.dataList = res.data.data
            });
          this.$store.dispatch('add2',this.$router.currentRoute.path);
//          console.log(this.$router.currentRoute.path)
    }
  }
</script>
<style scoped>
  .class{background: #fafafa}
  .banner{height:1.1rem;width: 100%;background: #ff9900;text-align: center;}
  .banner div{position: relative}
  .banner .ban{width: 100%}
  .banner .search{width:0.3rem;position: absolute;right:20%;top:40% }
  .banner input{height:0.4rem;width: 60%;background: #ffe1b5;border-radius: 0.1rem;margin-top: 0.2rem;padding-left: 0.2rem}
  .body ul{padding:0.2rem 0 0 0.1rem}
  .body li{width: 1.04rem;margin-right: 5%; margin-bottom: 0.23rem;border-radius: 0.05rem ;border: 0.03rem solid #1d84a7;}
  .body li img{width: 100%}
  .body li p{width: 100%;background: #1d84a7;text-align: center;color: #fff}
</style>
