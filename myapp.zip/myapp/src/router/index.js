import Vue from 'vue'
import Router from 'vue-router'
import index from '@/components/index'
import Main from '@/components/main'
import Class from '@/components/Class'
import buy from '@/components/buy'
import Me from '@/components/Me'
import detail from '@/components/detai'
import login from '@/components/login'
import register from '@/components/register'

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: '/index',
      name: 'index',
      component: index,
      children:[
        {
          path:'/main',
          component: Main,
        },
        {
          path:'/class',
          component: Class,
        },
        {
          path:'/buy',
          component: buy,
        },
        {
          path:'/Me',
          component: Me,
        },
      ]
    },
    {
      path:'/detail',
      component:detail
    },
    {
      path:'/login',
      component:login
    },
    {
      path:'/register',
      component:register
    },
    {
     path:'/*',
     redirect:'/main'
    }
  ]
})
