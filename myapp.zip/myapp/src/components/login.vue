<template>
  <div class="login">
    <div style="background: #f90">
      <img src="../../static/images/phone.jpg" alt="" width="100%">
      <div style="padding: 0.2rem;text-align: center" class="top">
        <span class="fl" @click="$router.go(-1)" style=" font-family: '楷体'"><</span>
        <span>登录</span>
        <span  class="fr" @click="register">注册</span>
      </div>
    </div>
    <ul style="padding: 0.3rem 0.2rem" class="content">
      <li style="font-size: 0.12rem">手机号：<input type="text" v-model="phone"  width="30%" ></li>
      <li style="font-size: 0.12rem">密码：<input type="password" v-model="password" width="40%"></li>
      <div style="overflow: hidden;margin: 0.2rem 0"><span class="fr" style="color:#999;">忘记密码</span></div>

    </ul>
    <div style="text-align: center"> <button @click="login" >登录</button></div>

  </div>
</template>
<script>
  export default{
      data(){
          return {
              phone:"",
              password:''
          }
      },
      methods:{
        register(){
            this.$router.push({
              path:'./register'
            })
        },
        login(){
          this.$http({
            url:'http://yd.msword.top/login?'+'phone='+this.phone+'&password='+this.password,
          }).then((res)=>{
            console.log(res.data.msg);
            if(res.data.msg==='登录成功。'){
                var obj={phone:this.phone,password:this.password,tag:true,name:'小不点'};
                sessionStorage.setItem('id',JSON.stringify(obj));
                this.$router.go(-1)
            }else{
                alert(res.data.msg)
            }
          })
        }
      }
  }
</script>
<style scoped>
  .login .top span{color:#fff;}
  .login .content li{line-height:1rem;border-bottom: 0.0005rem solid #333;}
  .login .content li input{height:0.5rem;background: transparent}
  .login  button{width: 60%;background: #f90;color:#fff;text-align: center;padding:0.1rem 0;outline:none;border-radius: 0.1rem;font-size: 0.12rem }
</style>
