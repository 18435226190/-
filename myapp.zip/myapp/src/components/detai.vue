<template>
  <div class="detail">
    <img src="../../static/images/phone.jpg" alt="" class="phone" >
    <div class="pic">
      <div class="bigImg">
        <img src="../../static/images/back.jpg" alt="" class="back" style="z-index: 22" @click="back()">
        <img src="../../static/images/buyed.jpg" alt="" class="buyed" style="z-index: 22" @click="fly()">
        <img src="../../static/images/more.jpg" alt="" class="more" style="z-index: 22">
      <div class="swiper-container">
        <div class="swiper-wrapper">
          <div class="swiper-slide" v-for="(item,index) in data.swiperImgArr" :key="index"><img :src="item" alt="" class="big"></div>
        </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination" style="position: relative"></div>
      </div>
      </div>
    </div>
    <div class="text">
      <p>
        <span>{{data.name}}</span>
        <i style="line-height: 0.2rem;"><img src="../../static/images/collection.jpg" alt="" width="80%"><br>收藏</i>
      </p>
      <div>
        <i>￥{{data.reduct_price}}</i> <span>{{parseInt(data.allowance*10)}}折</span><span v-if="data.isFreeShip">包邮</span><br><br>
        <em style="text-decoration: line-through">￥{{data.original_price}}</em>
        <i style="overflow: hidden;line-height: 0.2rem;width: 78%">
            <b class="fr" v-for="(val,i) in data.describe" :key="i">{{val}}</b>
        </i>
      </div>
    </div>

    <ul class="import">
      <li class="fl"><span class="chose" @click="on1()" id="on1">商品详情</span></li>
      <li class="fl"><span @click="on2()" id="on2">买家口碑</span></li>
    </ul>
    <!--图片详情-->
    <div style="text-align: center;" id="imgDetail">
        <img :src="value" alt="" v-for="value in data.shopDes" width="90%" style="vertical-align: bottom">
    </div>
    <!--买家评论-->
    <div class="comment" id="comment" style="display: none">
      <ul style="display:flex;text-align: center;margin-top:0.2rem;border-bottom: 0.01rem solid #ddd;border-top: 0.01rem solid #ddd;" class="one" id="title">
          <li><span class="cho" @click="all">全部评价</span></li>
          <li><span @click="goods">好评</span></li>
          <li><span @click="bad">差评</span></li>
          <li><span @click="display">晒单</span></li>
      </ul>
      <ul class="two" style="padding: 0 0.2rem;border-bottom: 0.01rem solid #ddd" v-for="(item,ind) in comment" :key="ind">
        <li>
          <div style="overflow: hidden">
            <span class="fl" style="color:#f90">{{item.buyerName}}</span>
            <span class="fr" style="color:#999">{{item.createTime | formatDate}}</span>
          </div>
          <div>
            <img :src="val" alt="" width="30%" v-for="(val,i) in item.postImg" :key="i">
          </div>
          <span style="color:#999">{{item.postDescribe}}</span>
          <p>管理员:{{item.adminReviews}}</p>
        </li>
      </ul>

    </div>
    <!--加入购物车-->
    <div class="buy">
      <em style="color: #999;margin-left: 0.2rem" class="fl" >总价：</em> <i class="fl">￥{{data.reduct_price*num}}</i>
      <span style="color: #fff;background: #ea2222;width: 30%;text-align: center" class="fr" >立即购买</span>
      <span style="color: #fff;background: #f90;width: 30%;text-align: center" class="fr" @click="buy()">加入购物车</span>
    </div>
    <!--加入-->
    <div id="join" style="display: none">
      <!--蒙版-->
      <div style="background: #333;width: 100%;height:20rem;opacity: 0.8;position: fixed;top:0;left:0;z-index: 1000">
      </div>
      <!--内容-->
      <div style="background: #fff;position: fixed;bottom: 0.5rem ;left:0;z-index:99999;width: 100%;opacity: 1;">
        <div>
          <img :src="data.swiperImgArr[0]" alt="" width="25%" style="position: absolute;top:-4%;left:5%"><span style="margin-left: 35%"><i>￥{{data.reduct_price}}</i><br><b>库存{{data.total}}件</b><br><b>请选择商品属性</b></span>
        <span class="fr" style="margin-top:0.2rem" @click="close()"><img src="../../static/images/more/close.png" alt="" width="60%"></span>
        </div>
        <div style="padding:0.2rem">
          <span>购买数量</span><span class="fr num"><b class="sub" style="border-left:0.01rem solid #cccccc" @click="sub">-</b><b class="num">{{num}}</b><b class="add" @click="add()">+</b></span>
        </div>
        <div  v-for="(val,x) in data.buySelect" class="last" :key="x">
          <p style="padding:0.02rem 0.2rem">{{val.name}}</p>
          <ul class="size" style="padding:0.05rem 0.2rem">
            <li v-for="(item,i) in val.list" :key="i" :class="[i==0?'active':'']"  @click="use(x,$event)">{{item}}</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import "../../node_modules/swiper/dist/css/swiper.min.css"
  import Swiper from 'swiper';
  import $ from 'jquery'
  export default {
      data(){
          return {
              data:{},
              comment:[],
              num:1,
              money:'',
              size:'',
              age:'',
              n:0
          }
      },
      methods:{
            back(){
                this.$router.go(-1)
            },
            on1(){
             $("#on1").addClass('chose');
             $("#on2").removeClass('chose');
             $("#imgDetail").css('display','block');
             $("#comment").css('display','none')
            },
            on2(){
              $("#on2").addClass('chose');
              $("#on1").removeClass('chose');
              $("#imgDetail").css('display','none');
              $("#comment").css('display','block')
            },
            all(){
              $('#title').find('span').removeClass('cho');
              $('#title li').eq(0).find('span').addClass('cho');
              console.log(this);
               this.comment=this.data.buyerReviews.all
          },
            goods(){
              $('#title').find('span').removeClass('cho');
              $('#title li').eq(1).find('span').addClass('cho');
               this.comment=this.data.buyerReviews.good
        },
            bad(){
              $('#title').find('span').removeClass('cho');
              $('#title li').eq(2).find('span').addClass('cho');
                this.comment=this.data.buyerReviews.bad
        },
            display(){
              $('#title').find('span').removeClass('cho');
              $('#title li').eq(3).find('span').addClass('cho');
                this.comment=this.data.buyerReviews.postForm
        },
            close(){
                $("#join").css("display",'none');
                this.n=0
            },
            buy(){
              $("#join").css("display",'block');
              if(this.n){
              if(sessionStorage.length){

//            数据
                var num=this.num;
                var obj={
                    content:[{num,title:this.size+this.age,flag:false}],
                    money:this.data.reduct_price,
                    name:this.data.name,
                    img:this.data.swiperImgArr[0],
                    tag:false
                };
              if(localStorage.getItem(this.data.pid)){
                var ob=JSON.parse(localStorage.getItem(this.data.pid));
                console.log(ob);
//                判断是否存在
                var a=0;
                ob.content.map((val)=>{
                  if(val.title===this.size+this.age){
                      val.num+=this.num;
                      a=1
                  }
                });
//                不存在
                if(a===0){
                    console.log(111);
                  ob.content.push({num,title:this.size+this.age,flag:false})
                }
                obj=ob
              }
                 localStorage.setItem(this.data.pid,JSON.stringify(obj));
                this.$router.push({
                  path:'./buy'
                })

                }else{
                    alert('请先登录');
                    this.$router.push('./login')
                }
              }
              this.n=1;

            },
            use(x,ev){
              console.log(ev.target.innerHTML);
              $(".size").eq(x).find('li').removeClass('active');
              ev.target.className='active';
              if(x===0){this.size=ev.target.innerHTML;console.log(this.size)}else{this.age=ev.target.innerHTML}
            },
            add(){
                this.num++
            },
            sub(){
                if(this.num>1){
                this.num--;}
      },
            fly(){
                this.$router.push('./buy')
            }
    },
      filters: {
        formatDate: function (value) {
//           return new Date(parseInt(value)).toLocaleString().replace(/:\d{1,2}$/,' ');
          var date = new Date(parseInt(value));
          var y = date.getFullYear();
          var MM = date.getMonth() + 1;
          MM = MM < 10 ? ('0' + MM) : MM;
          var d = date.getDate();
          d = d < 10 ? ('0' + d) : d;
          let h = date.getHours();
          h = h < 10 ? ('0' + h) : h;
          let m = date.getMinutes();
          m = m < 10 ? ('0' + m) : m;
          let s = date.getSeconds();
          s = s < 10 ? ('0' + s) : s;
          return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s;
        }
      },
      mounted(){
        this.$http({
          url:'http://yd.msword.top/getDetails?pid='+this.$router.currentRoute.query.id,
        }).then((res)=>{
            this.data=res.data.data;
            this.money=res.data.data.reduct_price;
            this.comment=res.data.data.buyerReviews.all;
            this.size=res.data.data.buySelect[0].list[0];
            this.age=res.data.data.buySelect[1].list[0];
            console.log(this.data.swiperImgArr);
          this.$nextTick(()=>{
            var swiper = new Swiper('.swiper-container', {
              pagination: {
                el:'.swiper-pagination',
              },
            });
          });
        });
      }
  }
</script>

<style scoped>
  .detail{background: #fff;position: relative;padding-bottom: 0.7rem}
  .phone{width: 100%;}
  .pic{position: relative;border-bottom: 0.03rem solid #eee}
  .pic .big{width: 100%}
  .pic .back,.buyed,.more{position: absolute;top:0.08rem;width: 7%;}
  .pic .back {left: 0.23rem}
  .pic .buyed{right:20%}
  .pic .more{right: 1%}
  .detail .text{padding:0.11rem 0.32rem 0.15rem 0.29rem;border-bottom: 0.32rem solid #eee}
  .detail p span{padding-right:7%;width:70%;border-right: 0.03rem solid #eee;margin-right: 5%}
  .detail p img{max-width: 0.36rem}
  .detail .text div span{background: #ff9900;color:#fff;padding: 0.06rem 0.12rem;margin-left: 0.24rem;     font-size: 0.12rem}
  .detail .text div em{font-size: 0.18rem;}
  .detail .text div b{padding:0.04rem 0.1rem;border: 0.02rem solid #ff9900;color:#ff9900;font-size: 0.14rem; margin-right: 2%;margin-bottom: 0.1rem;}
  .bigImg{position: relative}
  .import{display:flex;}
  .import li{flex:1;text-align: center}
  .import li span{width: 46%;line-height: 0.5rem}
  .import .chose{color:#f90;border-bottom: 0.05rem solid #f90;}
  .comment .one  li{flex: 1;text-align: center;padding: 0.2rem 0}
  .comment .one  li span{color:#ffff;width: 80%;background:#999999;line-height: 0.4rem;border-radius: 0.2rem }
  .comment .one  li .cho{background: #f90}
  .comment .two  li{padding:0.3rem 0}
  .comment .two  li p{color:#666;background: #ddd;border-radius: 0.1rem;padding: 0.1rem 0.1rem}
  .buy{overflow: hidden;position: fixed;left: 0;bottom: 0;background: #fff;width: 100%;z-index: 99999;border-top:0.01rem solid #999999}
  .buy span,i,em{line-height: 0.51rem}
  /*加入*/
   .num b{padding:0 0.1rem;display: inline-block;line-height:0.25rem;font-size:0.2rem;border:0.01rem solid #cccccc;
    border-left:none;text-align: center;}
    .size {display: flex}
    .size li{flex: 1;background: #ddd;text-align: center;margin: 3%;border-radius: 0.07rem;color:#999}
    .size .active{background: #f90;color:#fff}
</style>
