<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
  import index from './components/index.vue';
  import './assets/base.css'
export default {
  name: 'App',
  components:{
      index
  }
}
</script>

<style>

</style>
