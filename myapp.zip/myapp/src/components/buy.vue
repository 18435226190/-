<!--购物车-->
<template>
  <div class="buy">
    <div class="top" style="text-align: center;background: #f90;padding:0 0.2rem 0.2rem;">
    <img src="../../static/images/phone.jpg" alt="" width="100%" style="vertical-align: bottom" >
      <span class="fl" style="color:#fff;font-family: '楷体'" @click="go()">&lt;</span>
      <span style="color:#fff;font-size: 0.2rem">购物车</span>
    </div>
    <div class="main">
    <ul class="thing" v-for="(item,index) in dataList">
          <h2><img src="../../static/images/more/2.png" alt="" style="width: 5%;vertical-align: middle;margin-right: 3%" class="shop" @click="shop(index,$event)"><img src="../../static/images/more/1.jpg" alt="" style="vertical-align: bottom;width: 8%"><span style="margin-left: 5%;font-size: 0.2rem">商铺</span></h2>
      <li v-for="(val,ind) in item.content">
        <div>
          <img src="../../static/images/more/2.png" alt="" style="width: 4%;vertical-align: middle" @click="on(index,ind,$event)" class="zhong">
          <img :src="item.img" alt="" style="vertical-align: middle;margin-left: 0.1rem;width: 20%">
          <span style="width: 40%;color: #333">
              {{item.name}}
            <span style="color:#999">{{val.title}}</span>
            <p>
            <b class="sub" style="border-left:0.01rem solid #cccccc" @click="sub(index,ind)">-</b><b class="num">{{val.num}}</b><b class="add" @click="add(index,ind)">+</b>
            </p>
          </span>
          <b style="margin-top: 0.2rem">
            ￥{{item.money}}
          </b>
          <em class="" @click="del(index,ind,$event)">删除</em>
        </div>
      </li>
    </ul>
    <div class="bottom">
      <span style="width: 12%" @click="zhong()"><img src="../../static/images/more/2.png" alt="" style="width: 40%" class="zhong" id="all"><br>全选</span>
      <span style="width: 12%" @click="zhong1()"><img src="../../static/images/more/4.jpg" alt="" style="width: 40%" class="edit"><br>编辑</span>
      <span style="width: 31%;color:#999"> 合计:￥{{sum}} <br>(不含运费） </span>
      <span style="background: #ff5500;color:#fff;padding:0.1rem 0.15rem" class="fr">去结算</span>
    </div>
    </div>
    <div class="empty"><img src="../../static/images/more/empty.jpg" alt=""><br><span>购物车还是空的</span></div>
  </div>
</template>
<script>
  import $ from 'jquery'
  export default{
      data(){
          return {
              dataList:[],
              flag2:false,
              flag1:false,
          }
      },
      methods:{
//          返回
            go(){
              this.$router.go(-1);
            },
            add(a,b){
             var obj=JSON.parse(localStorage.getItem(localStorage.key(a)));
             obj.content[b].num++;
             localStorage.setItem(localStorage.key(a),JSON.stringify(obj));
             this.dataList[a].content[b].num++;
           },
            sub(a,b){
            var obj=JSON.parse(localStorage.getItem(localStorage.key(a)));
            if(obj.content[b].num>1){obj.content[b].num--;this.dataList[a].content[b].num--}
            localStorage.setItem(localStorage.key(a),JSON.stringify(obj));
          },
  //        单个选中
            on(a,b,event){
              this.dataList[a].content[b].flag=!this.dataList[a].content[b].flag;
              //控制图片变化
              if(this.dataList[a].content[b].flag){
                  event.target.src='../../static/images/more/2.jpg';
              }else{
                event.target.src='../../static/images/more/2.png';
              }
              //控制大图
              $('#all').attr('src','../../static/images/more/2.jpg');
              this.flag2=true;
              this.dataList.map((item)=>{

                    item.content.map(val=>{
                      if(!val.flag){
                        $('#all').attr('src','../../static/images/more/2.png');
                        this.flag2=false;
                      }
                    })
              });
              //控制商铺选中状态
              $('.shop').eq(a).attr('src','../../static/images/more/2.jpg');
              this.dataList[a].tag=true;
              this.dataList[a].content.map((val)=>{
                if(!val.flag){
                  $('.shop').eq(a).attr('src','../../static/images/more/2.png');
                  this.dataList[a].tag=false;
                }
              });
              //控制删除键
              if(this.flag1){
//                $('.edit').attr('src','../../static/images/more/4.png');
                this.dataList.map((item,index)=>{
                  item.content.map((val,ind)=>{
                    if(val.flag){
                      $('.thing').eq(index).find('em')[ind].className='del'
                    }else{
                      $('.thing').eq(index).find('em')[ind].className=''
                    }
                  })
                });
              }
              //
            },
  //        删除
            del(a,b,event){
              event.target.src='../../static/images/more/2.jpg';
              var obj=JSON.parse(localStorage.getItem(localStorage.key(a)));
              if($('.thing').eq(a).find('li').length<=1){
                this.dataList.splice(a,1);
                localStorage.removeItem(localStorage.key(a),JSON.stringify(obj));
              }else{
                obj.content.splice(b,1) ;
                localStorage.setItem(localStorage.key(a),JSON.stringify(obj));
                this.dataList[a].content.splice(b,1);
              }
  //            数据不为空时，取消默认选择
              let aa=this.dataList.every((val)=>{
                  return val==={}
              });
              if(!aa){
                this.dataList.map((item)=>{
                      item.content.map(val=>{
                        if(val.flag){
                          $('.thing').eq(a).find('.zhong')[b].src='../../static/images/more/2.jpg';
                          $('.thing').eq(a).find('em')[b].className='del'
                        }else{
                            console.log('出来？');
                          $('.thing').eq(a).find('.zhong')[b].src='../../static/images/more/2.png';
                          $('.thing').eq(a).find('em')[b].className=''
                        }
                      })
                });
                $('.empty').css('display','none')
              }else{
                $('.empty').css('display','block')
              }
              this.dataList.map((val,ind)=>{
                if(val.tag){
                  $('.shop').eq(ind).attr('src','../../static/images/more/2.jpg')  ;
                }else{
                  $('.shop').eq(ind).attr('src','../../static/images/more/2.png')  ;
                }
              })
            },
  //        全选
            zhong(){
                this.flag2=!this.flag2;
                if(this.flag2){
                  $(".zhong").attr('src',"../../static/images/more/2.jpg");
                  $(".shop").attr('src',"../../static/images/more/2.jpg");
                  this.dataList.map((item)=>{
                    item.tag=true;
                    item.content.map(val=>{
                      val.flag=true
                    })
                  });
                }else{
                  $(".zhong").attr('src',"../../static/images/more/2.png");
                  $(".shop").attr('src',"../../static/images/more/2.png");
                  this.dataList.map((item)=>{
                    item.tag=false;
                        item.content.map(val=>{
                          val.flag=false
                        })
                  });
                }
  //          删除键控制
              if(this.flag1){
                this.dataList.map((item,index)=>{
                  if(item){
                    item.content.map((val,ind)=>{
                      if(val.flag){
                        $('.thing').eq(index).find('em')[ind].className='del'
                      }else{
                        $('.thing').eq(index).find('em')[ind].className=''
                      }
                    })
                  }
                });
              }

          },
  //       编辑
            zhong1(){
          this.flag1=!this.flag1;
          if(this.flag1){

            $('.edit').attr('src','../../static/images/more/4.png');
            this.dataList.map((item,index)=>{
              if(item){
                  item.content.map((val,ind)=>{
                    if(val.flag){
                      $('.thing').eq(index).find('em')[ind].className='del'
                    }
                  })
                }
            });
          }else{
            $('.edit').attr('src','../../static/images/more/4.jpg');
            $('.thing').find('em').removeClass('del')
          }
        },
  //       商铺控制
            shop(x,ev){
              this.dataList[x].tag=!this.dataList[x].tag;
               if(this.dataList[x].tag){
                  ev.target.src='../../static/images/more/2.jpg';
               }else{
                  ev.target.src='../../static/images/more/2.png'
               }
  //         控制小的商品

              this.dataList[x].content.map((val)=>{
                val.flag=this.dataList[x].tag;
                $('.thing').eq(x).find('.zhong').attr('src',ev.target.src)
              });
              //控制删除键
              if(this.flag1){
//                $('.edit').attr('src','../../static/images/more/4.png');
                this.dataList.map((item,index)=>{
                  item.content.map((val,ind)=>{
                    if(!val.flag){
                      $('.thing').eq(index).find('em')[ind].className=''
                    }else{
                      $('.thing').eq(index).find('em')[ind].className='del'
                    }
                  })
                });
              }
            }
      },
      computed:{
          sum(){
              var money=0;
              this.dataList.map((item)=>{
                item.content.map(val=>{
                  if(val.flag){
                    money+=val.num*item.money
                  }
                })
              });
               return money
        }
      },
      mounted(){
        for(let i=0;i<localStorage.length;i++){
            console.log(Number(localStorage.key(i)));
            if(Number(localStorage.key(i))){
                this.$set(this.dataList,i,JSON.parse(localStorage.getItem(localStorage.key(i))))
            }
        }
//        没有购物车数据时
        let aa=this.dataList.every((val)=>{

          return val==={}
        });
        if(!aa){
          $('.empty').css('display','none')
        }else{
          $('.empty').css('display','block')
        }
//        未登录时
        if(sessionStorage.length>0){
          $('.empty').css('display','none');
          $('.main').css('display','block')
        }else{
          $('.empty').css('display','block');
          $('.main').css('display','none');
        }
        this.$store.dispatch('add2',this.$router.currentRoute.path);
      }
  }
</script>
<style scoped>
  .buy{position: relative;padding-bottom: 2rem}
  .thing{border: 0.01rem solid #ddd;margin-bottom: 0.2rem}
  .thing h2 {padding:0.2rem 0.1rem}
  .thing li {padding:0.1rem  0.1rem}
  .thing li span{margin-left: 0.1rem;color:#999;font-size: 0.12rem}
  .thing li div{margin-top: 0.2rem}
  .thing li p{margin-top: 0.2rem}
  .thing li p b{width:20%;display: inline-block;line-height:0.25rem;font-size:0.2rem;border:0.01rem solid #cccccc;
    border-left:none;text-align: center;}
  .bottom {width:100%;padding:0.1rem 0;background: #fff;border-top:0.01rem solid #eee;border-bottom:0.01rem solid #eee;position: fixed;bottom: 0.7rem;left:0}
  .bottom span{margin-left: 3%;text-align: center}
  .thing li em{width: 12%;line-height:0.5rem;text-align: center;color: #fff;float: right;display: none;background: #f90;}
  .thing li .del{display: inline-block}
  .empty{text-align: center;padding-top: 2rem}
</style>
