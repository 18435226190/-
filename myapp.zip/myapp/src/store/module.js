let module={
  state:{
    // 'msg':'厉害',
    path:'./main'
  },
  actions:{
    addNum(context){
      context.commit("adds")
    },
    add2(context,x){
      context.commit("add2",x)
    }
  },
  mutations:{
    add2(state,x){
      state.path=x
    }
  },
};
export default module

