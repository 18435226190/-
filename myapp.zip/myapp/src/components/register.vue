<template>
  <div class="register">
    <div style="background: #f90">
      <img src="../../static/images/phone.jpg" alt="" width="100%">
      <div style="padding: 0.2rem;text-align: center" class="top">
        <span class="fl"  @click="$router.go(-1)" style="font-family:'楷体'"><</span>
        <span>注册</span>
        <span  class="fr" @click="login()">登录</span>
      </div>
    </div>
    <ul style="padding: 0.3rem 0.2rem" class="content">
      <li>手机号：<input type="text" v-model="phone"></li>
      <li>密码：<input type="password" v-model="password"></li>
      <li>验证码：<input type="text" v-model='code'><span class="fr" style="color:#fb0140" @click="send()">点击获取</span></li>
    </ul>
    <div style="text-align: center"> <button @click="register()">下一步</button></div>
    <div style="padding: 0.3rem 0.2rem;color:#676767">
      <input type="checkbox" class="true" checked> 我已阅读并同意使用条款和隐私政策
    </div>
  </div>
</template>
<script>
  import qs from 'qs'
  import $ from 'jquery'
  export default {
      data(){
          return {
              phone:'',
              password:'',
              code:''
          }
      },
      methods:{
          login(){
              this.$router.push({
                path:'./login'
              })
          },
        send(){
          let reg=/^1[3-9]\d{9}$/;
          if(reg.test(this.phone)){
              this.$http({
                url:'http://localhost:3000/captcha/sent?phone='+this.phone
              }).then((res)=>{
                  console.log(res)
              })
          }else{
            alert("请输入正确的手机号")
          }
        },
        register(){
//              if($(":checkbox")[0].checked){
//                if(this.phone===''||this.code===''){
//                    alert('内容不能空')
//                }
//                else{
//                    if(this.password.length>=4){
//                        this.$http({
//                          url:'http://localhost:3000/captcha/verify?phone='+this.phone+'&captcha='+this.code
//                        }).then(res=>{
//                          if(res.status===200){

                            this.$http({
                              url:'http://yd.msword.top/register',
                              method:'post',
                              data:qs.stringify({phone:this.phone,password:this.password})
                            }).then((res)=>{
                              if(res.data.msg==="注册成功"){
                                  this.$router.push({
                                    path:'./login'
                                  })
                              }
                            })

//                          }
//                        });
//                    }
//                    else{
//                        alert("密码不安全")
//                    }
//                }
//              }else{
//                  alert("请先阅读使用条款")
//              }
//
//
        }
      }
  }
</script>
<style scoped>
  .register .top span{color:#fff;}
  .register .content li{line-height:1rem;border-bottom: 0.0005rem solid #333;}
  .register .content li input{height:0.5rem;background: transparent}
  .register  button{width: 80%;background: #f90;color:#fff;text-align: center;padding:0.2rem 0;outline:none;border-radius: 0.1rem }
  .true{width: 0.25rem;height: 0.25rem;}
</style>

