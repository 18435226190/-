<template>
  <div class="index">
    <router-view/>
    <ul class="bottom">
      <li @click="on1()">
        <router-link to="/main" active-class="act">
          <img :src="home" alt="" id="home"><br>首页
        </router-link>

      </li>
      <li @click="on2()">
        <router-link to="/class" active-class="act">
          <img :src="app" alt="" id="Class"><br>
          分类
        </router-link>
      </li>
      <li @click="on3()">
        <router-link to="/buy" active-class="act">
          <img :src="buy" alt="" id="buy"><br>
          购物车
        </router-link>
      </li>
      <li @click="on4()">
        <router-link to="/Me" active-class="act">
          <img :src="man" alt="" id="man"><br>
          我{{$store.state.module.num}}
        </router-link>
      </li>
    </ul>
  </div>
</template>
<script>
  export default {
      data(){
          return {
            imgArr:['../../static/images/home.jpg','../../static/images/home1.jpg',"../../static/images/app.jpg","../../static/images/app1.jpg","../../static/images/buy.jpg","../../static/images/buy1.jpg","../../static/images/man.jpg","../../static/images/man1.jpg"],
            home:'../../static/images/home1.jpg',
            app:'../../static/images/app.jpg',
            buy:'../../static/images/buy.jpg',
            man:'../../static/images/man.jpg',
          }
      },
    methods:{
        on1(){
            home.src=this.imgArr[1];
            Class.src=this.imgArr[2];
            buy.src=this.imgArr[4];
            man.src=this.imgArr[6]
        },
      on2(){
          home.src=this.imgArr[0];
          Class.src=this.imgArr[3];
          buy.src=this.imgArr[4];
          man.src=this.imgArr[6]
      },
      on3(){
          home.src=this.imgArr[0];
          Class.src=this.imgArr[2];
          buy.src=this.imgArr[5];
          man.src=this.imgArr[6]
      },
      on4(){
          home.src=this.imgArr[0];
          Class.src=this.imgArr[2];
          buy.src=this.imgArr[4];
          man.src=this.imgArr[7]
      }
    },
    mounted(){
      console.log(this.$router);
        if(this.$router.currentRoute.path==='/main'){
          home.src=this.imgArr[1];
          Class.src=this.imgArr[2];
          buy.src=this.imgArr[4];
          man.src=this.imgArr[6]
        }
        if(this.$router.currentRoute.path==='/class'){
          home.src=this.imgArr[0];
          Class.src=this.imgArr[3];
          buy.src=this.imgArr[4];
          man.src=this.imgArr[6]
        }
        if(this.$router.currentRoute.path==='/buy'){
          home.src=this.imgArr[0];
          Class.src=this.imgArr[2];
          buy.src=this.imgArr[5];
          man.src=this.imgArr[6]
        }
        if(this.$router.currentRoute.path==='/Me'){
          home.src=this.imgArr[0];
          Class.src=this.imgArr[2];
          buy.src=this.imgArr[4];
          man.src=this.imgArr[7]
        }
    },
    updated(){
      console.log(this.$router);
      if(this.$router.currentRoute.path==='/main'){
        home.src=this.imgArr[1];
        Class.src=this.imgArr[2];
        buy.src=this.imgArr[4];
        man.src=this.imgArr[6]
      }
      if(this.$router.currentRoute.path==='/class'){
        home.src=this.imgArr[0];
        Class.src=this.imgArr[3];
        buy.src=this.imgArr[4];
        man.src=this.imgArr[6]
      }
      if(this.$router.currentRoute.path==='/buy'){
        home.src=this.imgArr[0];
        Class.src=this.imgArr[2];
        buy.src=this.imgArr[5];
        man.src=this.imgArr[6]
      }
      if(this.$router.currentRoute.path==='/Me'){
        home.src=this.imgArr[0];
        Class.src=this.imgArr[2];
        buy.src=this.imgArr[4];
        man.src=this.imgArr[7]
      }
    }

  }

</script>
<style scoped>
  .index{background: #fafafa}
  .bottom{width:100%;height: 0.56rem;display: flex;border-top:0.05rem solid #eee;padding-top: 0.14rem;position: fixed;bottom: 0;left: 0;background: #fff}
  li{text-align: center;flex: 1}
  #home,#Class,#buy,#man, img{width: 0.2rem;height:0.2rem}
  .act{color:#ff9900}
</style>
